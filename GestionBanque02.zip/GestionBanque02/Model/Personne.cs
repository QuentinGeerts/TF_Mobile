﻿using System;

namespace GestionBanque02.Model
{
    public class Personne
    {
        // Auto-propriétés
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateNaiss { get; set; }
    }
}
