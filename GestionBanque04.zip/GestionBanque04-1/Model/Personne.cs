﻿using System;

namespace GestionBanque04_1.Model
{
    public class Personne
    {
        // Auto-propriétés
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateNaiss { get; set; }
    }
}
